/*
 * File:   can.c
 * Author: yokes
 *
 * Created on 14 May, 2025, 8:05 PM
 */


#include <xc.h>

void main(void) {
    return;
}
